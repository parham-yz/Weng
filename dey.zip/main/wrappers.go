package main

func makeDumC(pos [2]float64) (ng Object) {
	ng.Phfm = new(PhyzFm)
	ng.Phfm.Position = pos
	ng.Phfm.Shape = &GeoShape{
		Typee:      "circle",
		Properties: []float64{1},
	}
	ng.Phfm.MovmentPower = 1

	ng.HeaderFm.WishQueue.init(10)
	return
}
