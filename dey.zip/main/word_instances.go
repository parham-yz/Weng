package main

const (
	WISH_MOVE = iota
	WISH_SPAWN
	WISH_KILL
)

type Wish map[string]float64

type HeaderFm struct {
	Id        uint
	Tag       string
	WishQueue Queue
}

type PhyzFm struct {
	Present      bool
	Position     [2]float64
	Shape        *GeoShape
	MovmentPower int
}

type Intel interface {
	Decide()
	PushEnvSig(*EnvSig)
	GetSencRadius() [2]float64
}

type EnvSig struct {
	Type        int
	RelPolarPos [2]float64
	Reliability float64
}

type Object struct {
	HeaderFm
	Phfm  *PhyzFm
	Brain *Intel
}

func (obj *Object) MoveMe(dw, rw float64) {

	w := Wish{
		"receiver": 1,
		"id":       float64(obj.Id),
		"type":     WISH_MOVE,
		"dw":       dw,
		"rw":       rw,
	}
	obj.WishQueue.Push(w)
}
