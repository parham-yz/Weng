package main

type Crier struct {
	HeaderFm
	objBank *Bank
}

func (cr *Crier) Run() {
	for target := hw.objBank.ResetIter(); target != nil; target = hw.objBank.Iterate() {
		if target.Brain != nil {
			(*target.Brain).Decide()
		}
	}
}

func (cr *Crier) Init(objBank *Bank) *Crier {
	hw.objBank = objBank
	return hw
}

func sendSigs(){
	sig := new(EnvSig)
	tp := [2]float64{
		temp.Phfm.Position[0] - target.Phfm.Position[0],
		temp.Phfm.Position[1] - target.Phfm.Position[1]}

	sig.RelPolarPos = cartesianToPolar(tp)
	if sig.RelPolarPos[0] < (*target.Brain).GetSencRadius()[0] {
		// deterministic range:
		sig.Reliability = 1.0
		sig.Type = "exst-"+

	} else if sig.RelPolarPos[0] < (*target.Brain).GetSencRadius()[1] {

}