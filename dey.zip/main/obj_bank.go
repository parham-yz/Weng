package main

type bankNode struct {
	data *Object
	next *bankNode
}

type Bank struct {
	root   *bankNode
	cursor *bankNode
	end    *bankNode
}

func (bn *Bank) Add(data *Object) {

	if bn.root == nil {
		bn.root = new(bankNode)
		bn.end = bn.root
	} else {
		bn.end.next = new(bankNode)
		bn.end = bn.end.next
	}
	bn.end.data = data
	bn.end.next = nil
}

func (bn *Bank) Get(id uint) (*Object, bool) {

	cursor := bn.root
	ok := false
	for cursor != nil {
		if cursor.data.Id == id {
			ok = true
			break
		}
		cursor = cursor.next
	}
	return cursor.data, ok
}

func (bn *Bank) Del(id uint) bool {

	if bn.root == nil {
		return false
	}
	ok := false

	cursor := bn.root
	for cursor.next != nil {
		if cursor.next.data.Id == id {
			ok = true
			break
		}
		cursor = cursor.next
	}

	cursor.next = cursor.next.next
	return ok
}

func (bn *Bank) Find(id uint) *Object {

	cursor := bn.root
	for cursor != nil {
		if cursor.data.Id == id {
			return cursor.data
		}
		cursor = cursor.next
	}
	return nil
}

func (bn *Bank) Iterate() *Object {

	if bn.cursor.next == nil {
		return nil
	}
	bn.cursor = bn.cursor.next
	return bn.cursor.data
}

func (bn *Bank) ResetIter() *Object {

	bn.cursor = bn.root
	return bn.root.data
}

func (bn *Bank) Do(foo func(*Object)) {
}
