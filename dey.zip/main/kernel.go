package main

type Kernel struct {
	HeaderFm
	WorldList   *Bank
	idGenerator uint
	peng        *Phyz
	// how         *How
}

func (kr *Kernel) Init(objBank *Bank) {
	if kr.peng == nil {
		kr.peng = new(Phyz).Init(objBank, map[string]float64{
			"boundary type": BOUNDARY_STATIC,
			"boundary i":    10,
			"boundary j":    10,
		})
	}

	// if kr.how == nil {
	// 	kr.how = new(How).Init(objBank)
	// }

	kr.WorldList = objBank
	kr.WishQueue.init(100)
	kr.Id = 0
	kr.idGenerator = 10
}

func (kr *Kernel) DropIn(obj *Object) uint {

	obj.Id = kr.idGenerator
	kr.idGenerator++
	kr.WorldList.Add(obj)

	w := Wish{
		"receiver": 1,
		"id":       float64(obj.Id),
		"sponsor":  float64(kr.Id),
		"type":     WISH_SPAWN,
	}
	kr.peng.WishQueue.Push(w)

	return obj.Id
}

func (kr *Kernel) PullOut(id uint) {

	kr.WorldList.Del(id)
}

func (kr *Kernel) RouteWishes() {
	// routing kernel wishes
	kr.WishQueue.PushTo(&kr.peng.WishQueue)

	//Objs wishes :
	for target := kr.WorldList.ResetIter(); target != nil; target = kr.WorldList.Iterate() {
		for !target.WishQueue.empty {

			wish := target.WishQueue.Pop().(Wish)

			switch uint(wish["receiver"]) {
			case 0:
				kr.WishQueue.Push(wish)
			case 1:
				kr.peng.WishQueue.Push(wish)
			}
		}
	}
}

func (kr *Kernel) Run() {
	kr.RouteWishes()
	kr.peng.Run()

}
