package main

type void interface{}

// <?>
type Queue struct {
	waiters          []void
	first, last, len int
	empty, full      bool
}

func (qu *Queue) init(size uint) {
	qu.waiters = make([]void, size)
	qu.first = 0
	qu.last = 0
	qu.empty = true
	qu.full = false
	qu.len = 0
	return
}

func (qu *Queue) PushTo(other *Queue) bool {
	for !qu.empty {
		ok := other.Push(qu.Pop())
		if !ok {
			return true
		}
	}
	qu.len += other.len
	return false
}

func (qu *Queue) Push(elment void) bool {
	if qu.full {
		return true
	}
	qu.waiters[qu.last] = elment
	qu.last = (qu.last + 1) % cap(qu.waiters)

	if qu.empty {
		qu.empty = false
	}

	if qu.last == qu.first {
		qu.full = true
	}

	qu.len++
	return false
}

func (qu *Queue) Pop() (elment void) {
	if qu.empty {
		return nil
	}
	elment = qu.waiters[qu.first]
	qu.first = (qu.first + 1) % cap(qu.waiters)

	if qu.full {
		qu.full = false
	}

	if qu.last == qu.first {
		qu.empty = true
	}
	qu.len--
	return
}

type ObjList struct {
	root   *bankNode
	cursor *bankNode
	end    *bankNode
}

func (ols *ObjList) Add(data *Object) {

	if ols.root == nil {
		ols.root = new(bankNode)
		ols.end = ols.root
	} else {
		ols.end.next = new(bankNode)
		ols.end = ols.end.next
	}
	ols.end.data = data
	ols.end.next = nil
}

func (ols *ObjList) Get(index uint) (*Object, bool) {

	cursor := ols.root

	for index > 0 {
		if cursor == nil {
			return nil, false
		}
		cursor = cursor.next
		index--
	}
	return cursor.data, true
}

func (ols *ObjList) Flush() {
	ols.root = nil
}

func (ols *ObjList) Iterate() *Object {

	if ols.cursor.next == nil {
		return nil
	}
	ols.cursor = ols.cursor.next
	return ols.cursor.data
}

func (ols *ObjList) ResetIter() *Object {

	ols.cursor = ols.root
	return ols.root.data
}
