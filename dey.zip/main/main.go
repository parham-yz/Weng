package main

var kernel Kernel
var peng Phyz
var bank Bank

func main() {
	jimi := makeDumC([2]float64{6, 0})
	wall := makeDumC([2]float64{7, 7})

	kernel.peng = peng.Init(&bank, map[string]float64{
		"boundary type": BOUNDARY_STATIC,
		"boundary i":    10,
		"boundary j":    10,
	})

	kernel.Init(&bank)

	kernel.DropIn(&wall)
	kernel.DropIn(&jimi)

	for i := 0; i < 20; i++ {
		println(jimi.Phfm.Position[0], jimi.Phfm.Position[1])
		// println(jimi.Present)
		jimi.MoveMe(0.5, 0.5)
		kernel.Run()
		peng.Run()
	}
}
