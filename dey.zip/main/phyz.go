package main

import "math"

const (
	BOUNDARY_STATIC = iota
	BOUNDARY_CONTINOUOUS
)


type Phyz struct {
	HeaderFm
	serveQueue chan Wish
	objBank    *Bank
	woldProps  map[string]float64
	dirtyCache ObjList
}

// Init !!!
func (ph *Phyz) Init(objBank *Bank, woldProps map[string]float64) *Phyz {
	ph.WishQueue.init(1000)
	ph.objBank = objBank
	ph.woldProps = woldProps
	ph.Id = 1
	return ph
}

// CheckCollision checks global collision
func (ph *Phyz) CheckCollision(target *Object) (iss bool) {

	if !target.Phfm.Present {
		return false
	}

	iss = false
	ph.objBank.ResetIter()

	for iter := ph.objBank.ResetIter(); iter != nil; iter = ph.objBank.Iterate() {

		if iter.Phfm == nil || iter.Id == target.Id || !iter.Phfm.Present {
			continue
		}

		if haveCollision(target.Phfm, iter.Phfm) {
			iss = true
			break
		}
	}
	return iss
}

// spwans on object
func (ph *Phyz) spwan(target *Object) bool {
	if target.Phfm == nil {
		return false
	}

	target.Phfm.Present = true
	iss := ph.CheckCollision(target)
	if iss {
		target.Phfm.Present = false
		return false
	}
	return true
}

// Run !!!
func (ph *Phyz) Run() {

	//serving wishes
	for !ph.WishQueue.empty {
		wish, ok := ph.WishQueue.Pop().(Wish)
		if !ok {
			continue
		}

		target := ph.objBank.Find(uint(wish["id"]))
		if target.Phfm == nil {
			continue
		}

		// switching
		switch wish["type"] {

		case WISH_MOVE:

			if target.Phfm.Present {
				dw, lw := wish["dw"], wish["rw"]
				ph.moveCollider(target.Phfm, dw, lw)
				if ph.CheckCollision(target) {
					ph.moveCollider(target.Phfm, -dw, -lw)
				} else {
					ph.dirtyCache.Add(target)
				}
			}

		case WISH_SPAWN:

			if uint(wish["sponsor"]) == 0 {
				ph.spwan(target)
			}
		}
	}

	ph.dirtyCache.Flush()
}

// moves a cllider without collision check (one of the Phyz hands)
func (ph *Phyz) moveCollider(body *PhyzFm, downward, rightward float64) {
	body.Position[0] += downward
	body.Position[1] += rightward

	//boundary check
	boundI := ph.woldProps["boundary i"]
	boundJ := ph.woldProps["boundary j"]

	switch uint(ph.woldProps["boundary type"]) {

	case BOUNDARY_STATIC:

		if body.Position[0] > boundI {
			body.Position[0] = boundI
		}
		if body.Position[1] > boundJ {
			body.Position[1] = boundJ
		}
		if body.Position[0] < 0 {
			body.Position[0] = 0
		}
		if body.Position[1] < 0 {
			body.Position[1] = 0
		}

	case BOUNDARY_CONTINOUOUS:

		if body.Position[0] > boundI {
			body.Position[0] -= boundI
		}
		if body.Position[1] > boundJ {
			body.Position[1] -= boundJ
		}
		if body.Position[0] < 0 {
			body.Position[0] += boundI
		}
		if body.Position[1] < 0 {
			body.Position[1] += boundJ
		}
	}

}

// checks do a and b have collision (one of the Phyz hands)
func haveCollision(a, b *PhyzFm) bool {

	distance := math.Sqrt(math.Pow(a.Position[0]-b.Position[0], 2) + math.Pow(a.Position[1]-b.Position[1], 2))
	return a.Shape.Properties[0]+a.Shape.Properties[0] > distance
}

func (ph *Phyz) checkDistancesAndSig() {
	for target := ph.objBank.ResetIter(); target != nil; target = ph.objBank.Iterate() {
		for temp := ph.dirtyCache.ResetIter(); temp != nil; target = ph.dirtyCache.Iterate() {
			sig := new(EnvSig)
			tp := [2]float64{
				temp.Phfm.Position[0] - target.Phfm.Position[0],
				temp.Phfm.Position[1] - target.Phfm.Position[1]}

			sig.RelPolarPos = cartesianToPolar(tp)
			if sig.RelPolarPos[0] < (*target.Brain).GetSencRadius()[0] {
				// deterministic range:
				sig.Reliability = 1.0
				sig.Type = "exst-"+

			} else if sig.RelPolarPos[0] < (*target.Brain).GetSencRadius()[1] {

			}
		}
	}
}
